sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("materialmanagement.materialmanagement.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);